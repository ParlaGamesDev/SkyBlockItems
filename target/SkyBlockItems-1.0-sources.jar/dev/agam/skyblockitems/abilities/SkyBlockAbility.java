package dev.agam.skyblockitems.abilities;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;

import java.util.List;

public abstract class SkyBlockAbility {

    // ===== Hex Color Constants for consistent styling =====
    public static final String COLOR_MANA = "&#5B9BD5"; // Light Blue
    public static final String COLOR_COOLDOWN = "&#FF6B6B"; // Soft Red
    public static final String COLOR_DAMAGE = "&#FF8C42"; // Orange
    public static final String COLOR_RANGE = "&#7DCE82"; // Soft Green
    public static final String COLOR_DURATION = "&#DDA0DD"; // Light Purple
    public static final String COLOR_GOLD = "&#FFD700"; // Gold
    public static final String COLOR_WHITE = "&f"; // White
    public static final String COLOR_GRAY = "&7"; // Gray
    public static final String COLOR_TITLE = "&#E0E0E0"; // Light Gray for title

    // Additional Standard Colors
    public static final String COLOR_CYAN = "&#00D6FF"; // Aqua
    public static final String COLOR_RED = "&#FF0000"; // Red
    public static final String COLOR_GREEN = "&#20BC24"; // Green
    public static final String COLOR_YELLOW = "&#FFE300"; // Yellow

    private final String id;
    private final String displayName;
    private final List<String> description;
    private final TriggerType defaultTrigger;
    private double defaultCooldown;
    private double defaultManaCost;
    private double defaultDamage;
    private double defaultRange;
    private double defaultDuration;
    private double defaultPower;

    public SkyBlockAbility(String id, String displayName, TriggerType defaultTrigger,
            double defaultCooldown, double defaultManaCost, double defaultDamage, double defaultRange) {
        this(id, displayName, defaultTrigger, defaultCooldown, defaultManaCost, defaultDamage, defaultRange, 0, 0);
    }

    public SkyBlockAbility(String id, String displayName, TriggerType defaultTrigger,
            double defaultCooldown, double defaultManaCost, double defaultDamage, double defaultRange,
            double defaultDuration, double defaultPower) {
        this.id = id;

        // Load name and description from config if available, otherwise use default
        org.bukkit.configuration.file.FileConfiguration config = dev.agam.skyblockitems.SkyBlockItems.getInstance()
                .getAbilitiesConfig();
        String configPath = "custom-abilities." + id + ".name";
        String descPath = "custom-abilities." + id + ".description";

        // Check for common ID formats in config if exact match fails
        if (!config.contains(configPath)) {
            if (config.contains("custom-abilities." + id.toUpperCase() + ".name")) {
                configPath = "custom-abilities." + id.toUpperCase() + ".name";
                descPath = "custom-abilities." + id.toUpperCase() + ".description";
            } else if (config.contains("custom-abilities." + id.toLowerCase() + ".name")) {
                configPath = "custom-abilities." + id.toLowerCase() + ".name";
                descPath = "custom-abilities." + id.toLowerCase() + ".description";
            }
        }

        this.displayName = config.getString(configPath, displayName);
        this.description = config.getStringList(descPath);

        this.defaultTrigger = defaultTrigger;
        this.defaultCooldown = defaultCooldown;
        this.defaultManaCost = defaultManaCost;
        this.defaultDamage = defaultDamage;
        this.defaultRange = defaultRange;
        this.defaultDuration = defaultDuration;
        this.defaultPower = defaultPower;
    }

    public List<String> getDescription() {
        return description;
    }

    public List<String> getDescriptionWithPlaceholders(java.util.Map<String, String> placeholders) {
        List<String> result = new java.util.ArrayList<>();
        for (String line : description) {
            String processed = line;
            for (java.util.Map.Entry<String, String> entry : placeholders.entrySet()) {
                processed = processed.replace("{" + entry.getKey() + "}", entry.getValue());
            }
            result.add(processed);
        }
        return result;
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public TriggerType getDefaultTrigger() {
        return defaultTrigger;
    }

    public double getDefaultCooldown() {
        return defaultCooldown;
    }

    public double getDefaultManaCost() {
        return defaultManaCost;
    }

    public double getDefaultDamage() {
        return defaultDamage;
    }

    public double getDefaultRange() {
        return defaultRange;
    }

    public double getDefaultDuration() {
        return defaultDuration;
    }

    public double getDefaultPower() {
        return defaultPower;
    }

    public void setDefaultCooldown(double defaultCooldown) {
        this.defaultCooldown = defaultCooldown;
    }

    public void setDefaultManaCost(double defaultManaCost) {
        this.defaultManaCost = defaultManaCost;
    }

    public void setDefaultDamage(double defaultDamage) {
        this.defaultDamage = defaultDamage;
    }

    public void setDefaultRange(double defaultRange) {
        this.defaultRange = defaultRange;
    }

    /**
     * The logic to execute when triggered.
     * Values are passed in case they were overridden on the item.
     */
    public abstract boolean activate(Player player, Event event, double cooldown, double manaCost, double damage,
            double range);

    /**
     * Generate the lore lines for this ability.
     */
    public abstract List<String> getLore(double cooldown, double manaCost, double damage, double range,
            TriggerType trigger);

    // ===== Lore Formatting Helpers =====

    /**
     * Format the ability title line.
     * Example: "ראיית נץ | לחיצה ימנית"
     */
    protected String formatTitle(String name, TriggerType trigger) {
        return COLOR_GOLD + name + " " + COLOR_GRAY + "| " + COLOR_TITLE + trigger.getDisplayName();
    }

    /**
     * Format mana cost.
     * Example: "50 מאנה"
     */
    protected String formatMana(double mana) {
        return COLOR_MANA
                + dev.agam.skyblockitems.SkyBlockItems.getInstance().getConfigManager().getMessage("ability.lore.mana")
                        .replace("{mana}", String.valueOf((int) mana));
    }

    /**
     * Format cooldown.
     * Example: "5 שניות"
     */
    protected String formatCooldown(double cooldown) {
        if (cooldown >= 60) {
            int minutes = (int) (cooldown / 60);
            int seconds = (int) (cooldown % 60);
            if (seconds > 0) {
                return COLOR_COOLDOWN
                        + dev.agam.skyblockitems.SkyBlockItems.getInstance().getConfigManager()
                                .getMessage("ability.lore.cooldown-minutes")
                                .replace("{minutes}", String.valueOf(minutes))
                                .replace("{seconds}", String.valueOf(seconds));
            }
            return COLOR_COOLDOWN
                    + dev.agam.skyblockitems.SkyBlockItems.getInstance().getConfigManager()
                            .getMessage("ability.lore.cooldown-minutes-only")
                            .replace("{minutes}", String.valueOf(minutes));
        }
        return COLOR_COOLDOWN + dev.agam.skyblockitems.SkyBlockItems.getInstance().getConfigManager()
                .getMessage("ability.lore.cooldown-seconds")
                .replace("{cooldown}", String.format("%.1f", cooldown));
    }

    /**
     * Format damage.
     * Example: "10 נזק"
     */
    protected String formatDamage(double damage) {
        return COLOR_DAMAGE + dev.agam.skyblockitems.SkyBlockItems.getInstance().getConfigManager()
                .getMessage("ability.lore.damage")
                .replace("{damage}", String.format("%.1f", damage));
    }

    /**
     * Format range/radius.
     * Example: "רדיוס 10 בלוקים"
     */
    protected String formatRange(double range) {
        return COLOR_RANGE
                + dev.agam.skyblockitems.SkyBlockItems.getInstance().getConfigManager().getMessage("ability.lore.range")
                        .replace("{range}", String.valueOf((int) range));
    }

    /**
     * Format duration.
     * Example: "למשך 5 שניות"
     */
    protected String formatDuration(double seconds) {
        return COLOR_DURATION + dev.agam.skyblockitems.SkyBlockItems.getInstance().getConfigManager()
                .getMessage("ability.lore.duration")
                .replace("{seconds}", String.valueOf((int) seconds));
    }

    /**
     * Format standard mana and cooldown line.
     * Example: "עבור 50 מאנה ניתן להשתמש שוב לאחר 5 שניות"
     */
    protected String formatManaAndCooldown(double mana, double cooldown) {
        if (mana > 0 && cooldown > 0) {
            return COLOR_WHITE + dev.agam.skyblockitems.SkyBlockItems.getInstance().getConfigManager()
                    .getMessage("ability.lore.format")
                    .replace("{mana}", formatMana(mana))
                    .replace("{cooldown}", formatCooldown(cooldown));
        } else if (mana > 0) {
            return COLOR_WHITE
                    + dev.agam.skyblockitems.SkyBlockItems.getInstance().getConfigManager()
                            .getMessage("ability.lore.format-mana-only")
                            .replace("{mana}", formatMana(mana));
        } else if (cooldown > 0) {
            return COLOR_WHITE
                    + dev.agam.skyblockitems.SkyBlockItems.getInstance().getConfigManager()
                            .getMessage("ability.lore.format-cooldown-only")
                            .replace("{cooldown}", formatCooldown(cooldown));
        }
        return "";
    }
}
