package dev.agam.skyblockitems.reforge.gui;

import dev.agam.skyblockitems.SkyBlockItems;
import dev.agam.skyblockitems.enchantsystem.gui.BaseGUI;
import dev.agam.skyblockitems.enchantsystem.utils.ColorUtils;
import dev.agam.skyblockitems.reforge.Reforge;
import dev.agam.skyblockitems.reforge.ReforgeGem;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

/**
 * GUI for editing individual reforge properties.
 */
public class ReforgeEditorGUI implements BaseGUI {

    private final SkyBlockItems plugin;
    private final Player player;
    private final Inventory inventory;
    private final String reforgeId;
    private final boolean isNew;

    // Editable properties
    private String displayName;
    private List<String> itemTypes;
    private Map<String, Reforge.RarityData> rarityDataMap;
    private String selectedRarity = "COMMON";
    private ReforgeGem gem;

    public ReforgeEditorGUI(SkyBlockItems plugin, Player player, String reforgeId, boolean isNew) {
        this.plugin = plugin;
        this.player = player;
        this.reforgeId = reforgeId;
        this.isNew = isNew;

        // Load existing data or set defaults
        if (!isNew) {
            Reforge reforge = plugin.getReforgeManager().getReforge(reforgeId);
            if (reforge != null) {
                this.displayName = reforge.getDisplayName();
                this.itemTypes = new ArrayList<>(reforge.getItemTypes());
                this.rarityDataMap = new HashMap<>(reforge.getRarityDataMap());
                this.gem = reforge.getGem();
            }
        } else {
            // Defaults for new reforge
            this.displayName = "&e" + reforgeId;
            this.itemTypes = new ArrayList<>(Arrays.asList("ALL"));
            this.rarityDataMap = new HashMap<>();

            // Initialize standard rarities
            for (String r : Arrays.asList("COMMON", "RARE", "EPIC", "LEGENDARY", "MYTHIC", "DIVINE")) {
                rarityDataMap.put(r, new Reforge.RarityData(10000, new HashMap<>(), new ArrayList<>()));
            }
        }

        String title = ColorUtils
                .colorize(
                        plugin.getConfigManager().getMessage("reforge.editor.editor-title").replace("{id}", reforgeId));
        this.inventory = Bukkit.createInventory(this, 54, title);
        setupGUI();
    }

    @Override
    public void open() {
        player.openInventory(inventory);
    }

    private void setupGUI() {
        inventory.clear();

        // 1. Core Properties (Top Row)

        // Display Name
        inventory.setItem(10, createPropertyItem(Material.NAME_TAG,
                plugin.getConfigManager().getMessage("reforge.editor.properties.display-name.name"),
                Arrays.asList(
                        plugin.getConfigManager().getMessage("reforge.editor.labels.current-value"),
                        displayName,
                        "",
                        plugin.getConfigManager().getMessage("reforge.editor.properties.display-name.click"))));

        // Item Types
        inventory.setItem(11, createPropertyItem(Material.IRON_SWORD,
                plugin.getConfigManager().getMessage("reforge.editor.properties.item-types.name"),
                Arrays.asList(
                        plugin.getConfigManager().getMessage("reforge.editor.labels.current-value"),
                        "<#dfe6e9>" + String.join(", ", itemTypes),
                        "",
                        plugin.getConfigManager().getMessage("reforge.editor.properties.item-types.click"),
                        plugin.getConfigManager().getMessage("reforge.editor.properties.item-types.example"))));

        // Rarity SELECTOR (Slot 12)
        inventory.setItem(12, createPropertyItem(Material.NETHER_STAR,
                "§d§lSelect Rarity to Edit",
                Arrays.asList(
                        "§7Editing Data for: §b§l" + selectedRarity,
                        "",
                        "§eClick to cycle rarities!",
                        "§8(Stats, Cost, and Enchants below",
                        "§8apply to the selected rarity only)")));

        // Reforge Gem
        String gemStatus = gem != null ? "<#2ecc71>Required" : "<#dfe6e9>None";
        inventory.setItem(13, createPropertyItem(Material.CLOCK,
                "Reforge Gem",
                Arrays.asList(
                        plugin.getConfigManager().getMessage("reforge.editor.labels.current-value") + " " + gemStatus,
                        "",
                        "Click to edit Gem requirement",
                        "(If set, this reforge becomes VIP)")));

        // 2. Dynamic Properties (Middle Row - Based on Selected Rarity)
        Reforge.RarityData data = rarityDataMap.getOrDefault(selectedRarity,
                new Reforge.RarityData(0, new HashMap<>(), new ArrayList<>()));

        // Cost
        inventory.setItem(14, createPropertyItem(Material.GOLD_INGOT,
                plugin.getConfigManager().getMessage("reforge.editor.properties.cost.name") + " (§b" + selectedRarity
                        + "§f)",
                Arrays.asList(
                        plugin.getConfigManager().getMessage("reforge.editor.labels.current-value") + " <#2ecc71>"
                                + (int) data.getCost() + " מטבעות",
                        "",
                        plugin.getConfigManager().getMessage("reforge.editor.properties.cost.click"))));

        // Stats
        StringBuilder statsDisplay = new StringBuilder();
        Map<String, Double> stats = data.getStats();
        if (stats.isEmpty()) {
            statsDisplay.append(plugin.getConfigManager().getMessage("reforge.editor.properties.stats.none"));
        } else {
            for (Map.Entry<String, Double> entry : stats.entrySet()) {
                String translatedName = plugin.getReforgeManager().formatStatName(entry.getKey());
                statsDisplay.append("\n<#dfe6e9>").append(translatedName).append(": <#2ecc71>+")
                        .append(entry.getValue());
            }
        }
        inventory.setItem(19, createPropertyItem(Material.DIAMOND,
                plugin.getConfigManager().getMessage("reforge.editor.properties.stats.name") + " (§b" + selectedRarity
                        + "§f)",
                Arrays.asList(
                        plugin.getConfigManager().getMessage("reforge.editor.labels.current-value"),
                        statsDisplay.toString(),
                        "",
                        plugin.getConfigManager().getMessage("reforge.editor.properties.stats.click"),
                        plugin.getConfigManager().getMessage("reforge.editor.properties.stats.example"))));

        // Enchants
        List<String> enchants = data.getEnchants();
        inventory.setItem(20, createPropertyItem(Material.ENCHANTED_BOOK,
                plugin.getConfigManager().getMessage("reforge.editor.properties.enchants.name") + " (§b"
                        + selectedRarity + "§f)",
                Arrays.asList(
                        plugin.getConfigManager().getMessage("reforge.editor.labels.current-value"),
                        enchants.isEmpty()
                                ? plugin.getConfigManager().getMessage("reforge.editor.properties.enchants.none")
                                : "<#dfe6e9>" + String.join(", ", enchants),
                        "",
                        plugin.getConfigManager().getMessage("reforge.editor.properties.enchants.click"),
                        plugin.getConfigManager().getMessage("reforge.editor.properties.enchants.example"))));

        // Save button
        inventory.setItem(49, createPropertyItem(Material.EMERALD_BLOCK,
                plugin.getConfigManager().getMessage("reforge.editor.buttons.save"),
                Arrays.asList(
                        plugin.getConfigManager().getMessage("reforge.editor.buttons.save-lore"))));

        // Back button (Standardized: slot 48, Arrow material)
        inventory.setItem(48, createPropertyItem(Material.ARROW,
                plugin.getConfigManager().getMessage("gui.items.back.name"),
                plugin.getConfigManager().getMessageList("gui.items.back.lore")));

        // Filler
        Material fillerMat = Material.getMaterial(
                plugin.getConfig().getString("gui.list.filler-material", "PURPLE_STAINED_GLASS_PANE"));
        ItemStack filler = ColorUtils.createFillerItem(fillerMat);
        for (int i = 0; i < inventory.getSize(); i++) {
            if (inventory.getItem(i) == null || inventory.getItem(i).getType() == Material.AIR) {
                inventory.setItem(i, filler);
            }
        }
    }

    private ItemStack createPropertyItem(Material material, String name, List<String> loreLines) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ColorUtils.colorize(name));
        List<String> lore = new ArrayList<>();
        for (String line : loreLines) {
            lore.add(ColorUtils.colorize(line));
        }
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    public void onClick(InventoryClickEvent event) {
        if (event.getInventory().getHolder() != this)
            return;
        event.setCancelled(true);

        int slot = event.getSlot();
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR)
            return;

        // Save
        if (slot == 49) {
            plugin.getReforgeManager().saveReforge(reforgeId, displayName, itemTypes, rarityDataMap, gem);
            player.sendMessage(ColorUtils.colorize(plugin.getConfigManager().getMessage("reforge.editor.saved")));
            new ReforgeListGUI(plugin, player).open();
            return;
        }

        // Back
        if (slot == 48) {
            new ReforgeListGUI(plugin, player).open();
            return;
        }

        // Gem Editor
        if (slot == 13 || slot == 21) {
            new ReforgeGemEditorGUI(plugin, player, gem, this).open();
            return;
        }

        // Edit Display Name
        if (slot == 10) {
            promptInput("reforge.editor.properties.display-name.prompt", input -> {
                displayName = input;
                setupGUI();
            });
        }

        // Edit Item Types
        else if (slot == 11) {
            new ReforgeItemTypeSelectorGUI(plugin, player, itemTypes, this).open();
        }

        // Cycle Rarity Selector (Slot 12)
        else if (slot == 12) {
            List<String> rarities = Arrays.asList("COMMON", "RARE", "EPIC", "LEGENDARY", "MYTHIC", "DIVINE");
            int index = rarities.indexOf(selectedRarity);
            selectedRarity = rarities.get((index + 1) % rarities.size());
            setupGUI();
        }

        // Edit Cost (for currently selected Rarity)
        else if (slot == 14) {
            promptInput("reforge.editor.properties.cost.prompt", input -> {
                try {
                    double newCost = Double.parseDouble(input);
                    Reforge.RarityData old = rarityDataMap.get(selectedRarity);
                    rarityDataMap.put(selectedRarity,
                            new Reforge.RarityData(newCost, old.getStats(), old.getEnchants()));
                    setupGUI();
                } catch (NumberFormatException e) {
                    player.sendMessage(
                            ColorUtils.colorize(plugin.getConfigManager().getMessage("reforge.editor.invalid-number")));
                }
            });
        }

        // Edit Stats (Open GUI)
        else if (slot == 19) {
            Reforge.RarityData data = rarityDataMap.get(selectedRarity);
            new ReforgeStatEditorGUI(plugin, player, displayName + " (" + selectedRarity + ")", data.getStats(), this)
                    .open();
        }

        // Edit Enchants (Open GUI Selector)
        else if (slot == 20) {
            Reforge.RarityData data = rarityDataMap.get(selectedRarity);
            new ReforgeEnchantSelectorGUI(plugin, player, data.getEnchants(), this).open();
        }

    }

    private void promptInput(String messageKey, java.util.function.Consumer<String> callback) {
        player.closeInventory();
        String message = plugin.getConfigManager().getMessage(messageKey);
        player.sendMessage(ColorUtils.colorize(message));
        plugin.getChatInputManager().awaitInput(player, input -> {
            callback.accept(input);
            reopen();
        });
    }

    /**
     * Updates enchants list from sub-GUI for the SELECTED rarity.
     */
    public void updateEnchants(List<String> newEnchants) {
        Reforge.RarityData old = rarityDataMap.get(selectedRarity);
        rarityDataMap.put(selectedRarity, new Reforge.RarityData(old.getCost(), old.getStats(), newEnchants));
        setupGUI();
    }

    /**
     * Updates stats map from sub-GUI for the SELECTED rarity.
     */
    public void updateStats(Map<String, Double> newStats) {
        Reforge.RarityData old = rarityDataMap.get(selectedRarity);
        rarityDataMap.put(selectedRarity, new Reforge.RarityData(old.getCost(), newStats, old.getEnchants()));
        setupGUI();
    }

    public void reopen() {
        setupGUI();
        player.openInventory(inventory);
    }

    /**
     * Callback from ReforgeItemTypeSelectorGUI to update item types.
     */
    public void updateItemTypes(List<String> newItemTypes) {
        this.itemTypes = new ArrayList<>(newItemTypes);
    }

    public void updateGem(ReforgeGem newGem) {
        this.gem = newGem;
        setupGUI();
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
